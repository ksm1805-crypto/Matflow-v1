// 기존에는 const 앞에 export가 없었습니다.
// 외부에서 import { USERS_DB_KEY } ... 로 쓰려면 반드시 export를 붙여야 합니다.

export const STORAGE_KEY = 'oled_matflow_db_v1';
export const LICENSE_KEY_STORAGE = 'oled_matflow_license_key_v1';
export const GLOBAL_INVENTORY_KEY = 'oled_matflow_global_inventory_v1';
export const USERS_DB_KEY = 'oled_matflow_users_v1';

export const api = {
  materials: {
    getAll: async () => {
      // TODO: 백엔드 연결 시 axios.get('/api/materials') 로 변경
      if (window.electronAPI) return await window.electronAPI.loadData();
      const data = localStorage.getItem(STORAGE_KEY);
      return data ? JSON.parse(data) : [];
    },
    saveAll: async (materials) => {
      // TODO: 백엔드 연결 시 axios.post('/api/materials/sync', materials) 로 변경
      if (window.electronAPI) return await window.electronAPI.saveData(materials);
      localStorage.setItem(STORAGE_KEY, JSON.stringify(materials));
      return true;
    }
  },
  inventory: {
    getGlobal: async () => {
      // TODO: 백엔드 연결 시 axios.get('/api/inventory/master') 로 변경
      const data = localStorage.getItem(GLOBAL_INVENTORY_KEY);
      return data ? JSON.parse(data) : [];
    },
    saveGlobal: async (inventory) => {
      localStorage.setItem(GLOBAL_INVENTORY_KEY, JSON.stringify(inventory));
    }
  },
  license: {
    get: async () => {
       if (window.electronAPI) return await window.electronAPI.getLicense();
       const saved = localStorage.getItem(LICENSE_KEY_STORAGE);
       return saved ? JSON.parse(saved) : null;
    },
    save: async (data) => {
       if (window.electronAPI) return await window.electronAPI.saveLicense(data);
       localStorage.setItem(LICENSE_KEY_STORAGE, JSON.stringify(data));
    }
  },
  users: {
      getAll: () => {
          const stored = localStorage.getItem(USERS_DB_KEY);
          return stored ? JSON.parse(stored) : [];
      },
      saveAll: (users) => localStorage.setItem(USERS_DB_KEY, JSON.stringify(users))
  }
};