import React, { useState } from 'react';
import { Icon } from '../../components/ui/Icon';
import { ImageUploader } from '../../components/ui/ImageUploader';
import { generateId } from '../../utils/math';
import { fmtN } from '../../utils/format';

export const MasterStockTab = ({ globalInventory, updateGlobalInventory, readOnly }) => {
    const [searchTerm, setSearchTerm] = useState('');

    const addGlobalItem = () => {
        if(readOnly) return;
        const newItem = { 
            id: generateId(), 
            fullname: 'New Chemical', 
            manufacturer: '', 
            lotNo: '', 
            totalQty: '0',
            currentStock: '0',
            receiveDate: new Date().toISOString().split('T')[0], 
            location: '', 
            purity: '', 
            isScaleUp: false,
            structureImg: null 
        };
        updateGlobalInventory([...globalInventory, newItem]);
    };

    const updateItem = (id, field, val) => {
        if(readOnly) return;
        const newInv = globalInventory.map(item => {
            if (item.id === id) {
                const updated = { ...item, [field]: val };
                if (field === 'totalQty') {
                    const usedSoFar = (parseFloat(item.totalQty) || 0) - (parseFloat(item.currentStock) || 0);
                    updated.currentStock = ((parseFloat(val) || 0) - usedSoFar).toString();
                }
                return updated;
            }
            return item;
        });
        updateGlobalInventory(newInv);
    };

    return (
        <div className="p-4 h-full flex flex-col space-y-4 bg-slate-100">
            <div className="flex justify-between items-center bg-white p-4 rounded-xl shadow-sm border border-slate-200">
                <h2 className="text-xl font-black text-slate-900 flex items-center gap-2">
                    <Icon name="package" className="text-brand-600" size={24}/> 
                    MASTER STOCK
                </h2>
                <div className="flex gap-3">
                    <input 
                        className="pl-4 pr-4 py-1.5 bg-slate-50 border-2 border-slate-200 rounded-xl text-sm outline-none focus:border-brand-500 w-72 font-bold text-slate-800" 
                        placeholder="Search Master DB..." 
                        value={searchTerm} 
                        onChange={e=>setSearchTerm(e.target.value)}
                    />
                    {!readOnly && (
                        <button onClick={addGlobalItem} className="bg-slate-900 text-white px-5 py-1.5 rounded-xl text-xs font-black hover:bg-black transition shadow-md active:scale-95">
                            + ADD ITEM
                        </button>
                    )}
                </div>
            </div>

            <div className="flex-1 bg-white rounded-2xl shadow-xl border border-slate-200 overflow-hidden flex flex-col">
                <div className="overflow-auto h-full custom-scrollbar">
                    <table className="w-full text-left border-collapse min-w-[1200px]">
                        <thead className="bg-slate-100 sticky top-0 z-30 border-b-2 border-slate-300">
                            <tr className="text-black text-[11px] font-black uppercase">
                                <th className="px-4 py-2 w-20 text-center border-r border-slate-200">Scale</th>
                                <th className="px-4 py-2 w-24 text-center border-r border-slate-200">Structure</th>
                                <th className="px-6 py-2 border-r border-slate-200">Name / Maker</th>
                                <th className="px-6 py-2 w-40 border-r border-slate-200">Lot Number</th>
                                <th className="px-4 py-2 w-36 text-center border-r border-slate-200">In-Date</th>
                                <th className="px-4 py-2 w-24 text-center border-r border-slate-200">Total</th>
                                <th className="px-4 py-2 w-24 text-right text-emerald-600">Stock</th>
                                <th className="px-3 py-2 w-12"></th>
                            </tr>
                        </thead>
                        <tbody className="divide-y divide-slate-100 text-[12px]">
                            {globalInventory.filter(i => !searchTerm || (i.fullname||'').toLowerCase().includes(searchTerm.toLowerCase())).map(item => (
                                <tr key={item.id} className={`hover:bg-blue-50/40 transition-colors group ${item.isScaleUp ? 'bg-amber-50/30' : ''}`}>
                                    <td className="px-4 py-1.5 text-center border-r border-slate-50">
                                        <button onClick={() => updateItem(item.id, 'isScaleUp', !item.isScaleUp)} className={`transition-transform hover:scale-110 ${item.isScaleUp ? 'text-amber-500' : 'text-slate-200'}`}>
                                            <Icon name="star" size={20} className={item.isScaleUp?'fill-current':''}/>
                                        </button>
                                    </td>
                                    <td className="px-4 py-1.5 border-r border-slate-50">
                                        <div className="w-12 h-12 border border-slate-200 rounded-lg bg-white overflow-hidden shadow-sm mx-auto">
                                            <ImageUploader value={item.structureImg} onChange={v => updateItem(item.id, 'structureImg', v)} readOnly={readOnly}/>
                                        </div>
                                    </td>
                                    <td className="px-6 py-1.5 border-r border-slate-50">
                                        <input className="w-full text-[14px] font-black text-slate-800 bg-transparent outline-none" value={item.fullname} onChange={e=>updateItem(item.id, 'fullname', e.target.value)}/>
                                        <input className="w-full text-[10px] font-bold text-slate-400 bg-transparent outline-none italic" value={item.manufacturer || ''} onChange={e=>updateItem(item.id, 'manufacturer', e.target.value)} placeholder="Maker..."/>
                                    </td>
                                    <td className="px-6 py-1.5 border-r border-slate-50">
                                        <input className="w-full font-bold text-slate-600 bg-transparent outline-none font-mono" value={item.lotNo} onChange={e=>updateItem(item.id, 'lotNo', e.target.value)}/>
                                    </td>
                                    <td className="px-4 py-1.5 text-center border-r border-slate-50">
                                        <input type="date" className="bg-slate-50 border border-slate-200 rounded px-1.5 py-0.5 text-[11px] font-bold text-slate-700 outline-none" value={item.receiveDate} onChange={e=>updateItem(item.id, 'receiveDate', e.target.value)}/>
                                    </td>
                                    <td className="px-4 py-1.5 text-center border-r border-slate-50">
                                        <input type="number" className="w-16 bg-slate-50 border border-slate-200 rounded text-center font-black text-slate-700 outline-none py-0.5" value={item.totalQty} onChange={e=>updateItem(item.id, 'totalQty', e.target.value)}/>
                                    </td>
                                    <td className="px-4 py-1.5 text-right bg-emerald-50/10 border-r border-slate-50">
                                        <span className="text-[14px] font-black text-emerald-700 font-mono">{fmtN(item.currentStock, 1)}</span>
                                        <span className="text-[10px] font-bold text-emerald-500 ml-0.5">g</span>
                                    </td>
                                    <td className="px-3 py-1.5 text-center">
                                        <button onClick={() => updateGlobalInventory(globalInventory.filter(g=>g.id!==item.id))} className="text-slate-300 hover:text-rose-500 transition-all opacity-0 group-hover:opacity-100">
                                            <Icon name="trash-2" size={16}/>
                                        </button>
                                    </td>
                                </tr>
                            ))}
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    );
};