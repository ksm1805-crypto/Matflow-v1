import React, { useState } from 'react';
import { Icon } from '../../components/ui/Icon';
import { generateId } from '../../utils/math';
import { fmtN } from '../../utils/format';

export const ProjectInventoryTab = ({ material, updateMaterial, readOnly, globalInventory, updateGlobalInventory }) => {
    const [searchTerm, setSearchTerm] = useState('');
    
    // 프로젝트 내 원료 정보 수정 (사용량 입력 시 마스터 재고 실시간 차감 로직 포함)
    const updateProjectItem = (id, field, val) => {
        if(readOnly) return;
        
        const currentItem = material.inventory.find(i => i.id === id);
        if (!currentItem) return;

        if (field === 'usedQty') {
            const oldUsed = parseFloat(currentItem.usedQty) || 0;
            const newUsed = parseFloat(val) || 0;
            const diff = newUsed - oldUsed;

            // 마스터 스톡 연동: 사용량이 늘어나면 마스터 재고는 줄어듦
            if (currentItem.globalId) {
                const newGlobalInv = globalInventory.map(g => 
                    g.id === currentItem.globalId 
                    ? { ...g, currentStock: (parseFloat(g.currentStock) - diff).toString() } 
                    : g
                );
                updateGlobalInventory(newGlobalInv);
            }
        }

        const updatedInventory = material.inventory.map(item => 
            item.id === id ? { ...item, [field]: val } : item
        );
        updateMaterial({ ...material, inventory: updatedInventory });
    };

    // 마스터 스톡에서 프로젝트로 원료 추가 (Arrow Button 기능)
    const pushToProject = (globalItem) => {
        if(readOnly) return;
        if (material.inventory.some(i => i.globalId === globalItem.id)) {
            alert("This material is already added to the project."); 
            return;
        }
        
        const newItem = { 
            id: generateId(), 
            globalId: globalItem.id, 
            fullname: globalItem.fullname, 
            manufacturer: globalItem.manufacturer, 
            lotNo: globalItem.lotNo, 
            usedQty: '0', 
            location: globalItem.location || '', 
            user: '' 
        };

        updateMaterial({ 
            ...material, 
            inventory: [...material.inventory, newItem] 
        });
    };

    const filteredGlobal = globalInventory.filter(item => 
        !searchTerm || (item.fullname || '').toLowerCase().includes(searchTerm.toLowerCase())
    );

    return (
        <div className="flex flex-col h-full bg-slate-100 overflow-hidden">
            <div className="flex-1 flex overflow-hidden">
                {/* [LEFT] Master Stock List (Source) */}
                <div className="w-5/12 flex flex-col border-r-2 border-slate-200 bg-white">
                    <div className="p-5 border-b-2 border-slate-100 bg-slate-50/50">
                        <h3 className="text-lg font-black text-slate-900 flex items-center gap-2">
                            <Icon name="package" className="text-slate-500"/> MASTER STOCK
                        </h3>
                        <input 
                            className="w-full mt-3 bg-white border-2 border-slate-200 rounded-xl px-4 py-2 text-sm font-bold text-slate-800 outline-none focus:border-brand-500 shadow-sm" 
                            placeholder="Search Master..." 
                            value={searchTerm} 
                            onChange={e=>setSearchTerm(e.target.value)} 
                        />
                    </div>
                    <div className="flex-1 overflow-y-auto custom-scrollbar">
                        <table className="w-full text-sm border-collapse">
                            <thead className="bg-slate-100 text-slate-600 uppercase text-[10px] font-black sticky top-0 z-10 border-b-2 border-slate-200">
                                <tr>
                                    <th className="p-3 pl-5 text-left text-black">Name / Lot</th>
                                    <th className="p-3 w-28 text-right text-emerald-700">Stock</th>
                                    <th className="p-3 w-16 text-center text-black">Add</th>
                                </tr>
                            </thead>
                            <tbody className="divide-y divide-slate-100 font-bold">
                                {filteredGlobal.map(item => (
                                    <tr key={item.id} className="hover:bg-slate-50 transition-colors group">
                                        <td className="p-3 pl-5 text-slate-900">
                                            <div className="text-sm font-black truncate max-w-[150px]">{item.fullname}</div>
                                            <div className="text-[10px] text-slate-400 font-mono truncate">{item.lotNo}</div>
                                        </td>
                                        <td className="p-3 text-right font-black text-emerald-600 font-mono text-base">{fmtN(item.currentStock, 1)}g</td>
                                        <td className="p-3 text-center">
                                            <button onClick={() => pushToProject(item)} className="p-2 bg-slate-900 text-white rounded-full hover:bg-brand-600 transition shadow-md active:scale-90">
                                                <Icon name="plus" size={16}/>
                                            </button>
                                        </td>
                                    </tr>
                                ))}
                            </tbody>
                        </table>
                    </div>
                </div>

                {/* [RIGHT] Project Allocation List (Destination) */}
                <div className="w-7/12 flex flex-col bg-slate-50">
                    <div className="p-5 border-b-2 border-slate-200 bg-white flex justify-between items-center shadow-sm">
                        <h3 className="text-lg font-black text-brand-700 flex items-center gap-2"><Icon name="layers" size={20}/> PROJECT ALLOCATION</h3>
                        <div className="text-[10px] font-black text-slate-400 uppercase tracking-widest bg-slate-100 px-3 py-1 rounded-full">Items used in this project</div>
                    </div>
                    <div className="flex-1 overflow-y-auto custom-scrollbar p-4 space-y-2">
                        {material.inventory.length === 0 ? (
                            <div className="h-full flex flex-col items-center justify-center text-slate-300 italic opacity-60">
                                <Icon name="package" size={48} className="mb-2"/>
                                <p>Select materials from the Master Stock (Left) to add here.</p>
                            </div>
                        ) : (
                            material.inventory.map(item => {
                                const linkedGlobal = globalInventory.find(g => g.id === item.globalId);
                                return (
                                    <div key={item.id} className="bg-white p-2.5 rounded-xl border border-slate-200 shadow-sm hover:shadow-md transition-all border-l-4 border-l-brand-500">
                                        <div className="flex items-center gap-3">
                                            {/* 이미지 영역 */}
                                            {linkedGlobal?.structureImg && (
                                                <div className="w-10 h-10 rounded-lg border border-slate-100 overflow-hidden shrink-0 bg-white shadow-inner">
                                                    <img src={linkedGlobal.structureImg} className="w-full h-full object-contain"/>
                                                </div>
                                            )}
                                            
                                            {/* 정보 레이아웃 */}
                                            <div className="flex-1 min-w-0 grid grid-cols-12 gap-2 items-center">
                                                <div className="col-span-4 truncate">
                                                    <div className="font-black text-slate-950 text-[13px] truncate leading-tight">{item.fullname}</div>
                                                    <div className="text-[9px] font-black text-slate-400 font-mono mt-0.5">LOT: {item.lotNo}</div>
                                                </div>

                                                {/* Global 잔여 재고 표시 */}
                                                <div className="col-span-2 text-center border-l border-slate-100">
                                                    <label className="text-[8px] font-black text-slate-400 uppercase block">Global</label>
                                                    <div className="text-[11px] font-black font-mono text-slate-700">
                                                        {linkedGlobal ? fmtN(linkedGlobal.currentStock, 1) : '0.0'}g
                                                    </div>
                                                </div>

                                                {/* 사용량 입력 */}
                                                <div className="col-span-3">
                                                    <div className="flex items-center bg-brand-50 border border-brand-200 rounded-lg px-2 py-0.5 shadow-sm">
                                                        <input 
                                                            disabled={readOnly}
                                                            type="number"
                                                            step="0.1"
                                                            className="w-full bg-transparent text-right font-black text-brand-700 text-[13px] outline-none" 
                                                            value={item.usedQty} 
                                                            onChange={e => updateProjectItem(item.id, 'usedQty', e.target.value)} 
                                                        />
                                                        <span className="text-[9px] font-black text-brand-400 ml-1">g</span>
                                                    </div>
                                                </div>

                                                {/* Loc/User 정보 */}
                                                <div className="col-span-3 flex flex-col gap-0.5 justify-center border-l border-slate-100 pl-2">
                                                    <div className="flex items-center gap-1">
                                                        <Icon name="package" size={10} className="text-slate-300"/>
                                                        <input disabled={readOnly} className="w-full bg-transparent text-[10px] text-slate-500 outline-none font-bold" placeholder="Loc" value={item.location || ''} onChange={e=>updateProjectItem(item.id, 'location', e.target.value)}/>
                                                    </div>
                                                    <div className="flex items-center gap-1">
                                                        <Icon name="user" size={10} className="text-slate-300"/>
                                                        <input disabled={readOnly} className="w-full bg-transparent text-[10px] text-slate-500 outline-none font-bold" placeholder="User" value={item.user || ''} onChange={e=>updateProjectItem(item.id, 'user', e.target.value)}/>
                                                    </div>
                                                </div>
                                            </div>

                                            {/* 삭제 버튼 */}
                                            {!readOnly && (
                                                <button onClick={() => updateMaterial({...material, inventory: material.inventory.filter(i=>i.id!==item.id)})} className="text-slate-300 hover:text-rose-600 transition-colors shrink-0">
                                                    <Icon name="x" size={18}/>
                                                </button>
                                            )}
                                        </div>
                                    </div>
                                );
                            })
                        )}
                    </div>
                </div>
            </div>
        </div>
    );
};