import React, { useState, useMemo } from 'react';
import { Card } from '../../components/ui/Card';
import { Icon } from '../../components/ui/Icon';
import { SimpleLineChart } from '../../components/charts/SimpleLineChart';
import { fmtK } from '../../utils/format';
import { processCrossLotImpurityData } from '../../utils/math';
import { STANDARD_METALS } from '../../constants';

export const AnalysisHistoryTab = ({ material, updateMaterial, readOnly }) => {
    const [refLotIds, setRefLotIds] = useState(material.lots.length > 0 ? [material.lots[0].id] : []);
    const [isRefSelectorOpen, setIsRefSelectorOpen] = useState(false);

    const impurityComparisonData = useMemo(() => processCrossLotImpurityData(material.lots), [material.lots]);
    
    // Lot 업데이트 함수
    const updateLot = (id, field, val) => { 
        if(!readOnly) updateMaterial({ ...material, lots: material.lots.map(l => l.id === id ? { ...l, [field]: val } : l) }); 
    };

    const toggleRef = (id) => {
        setRefLotIds(prev => prev.includes(id) ? prev.filter(x => x !== id) : [...prev, id]);
    };

    const renderMixInfo = (lot) => {
        if (!lot.isMix) return '-';
        if (lot.mixCount === 3) {
            return (
                <div className="flex flex-col items-center">
                    <span className="text-[10px] text-slate-500 font-bold mb-0.5">{lot.comp1Label}/{lot.comp2Label}/{lot.comp3Label}</span>
                    <span className="bg-amber-100 text-amber-700 px-2 py-0.5 rounded text-xs font-bold">{lot.pRatio}:{lot.nRatio}:{lot.mixRatio3}</span>
                </div>
            );
        }
        return (
            <div className="flex flex-col items-center">
                <span className="text-[10px] text-slate-500 font-bold mb-0.5">{lot.comp1Label}/{lot.comp2Label}</span>
                <span className="bg-amber-100 text-amber-700 px-2 py-0.5 rounded text-xs font-bold">{lot.pRatio}:{lot.nRatio}</span>
            </div>
        );
    };

    const renderDRate = (lot) => {
        if (lot.isMix) {
            return (
                <div className="flex flex-col text-[10px] font-mono leading-tight">
                    <span className="text-blue-600">{lot.comp1Label}: {lot.dRateP || '-'}%</span>
                    <span className="text-rose-600">{lot.comp2Label}: {lot.dRateN || '-'}%</span>
                    {lot.mixCount === 3 && <span className="text-emerald-600">{lot.comp3Label}: {lot.dRate3 || '-'}%</span>}
                </div>
            );
        }
        return <span className="font-mono text-slate-700">{lot.dRate ? `${lot.dRate}%` : '-'}</span>;
    };

    const renderHalogen = (lot) => {
        const { f, cl, br } = lot.halogen || {};
        const spec = material.specification?.halogen || {};
        const checkFail = (val, limit) => { if (!limit || limit === '') return false; return (parseFloat(val) || 0) > parseFloat(limit); };
        const fFail = checkFail(f, spec.f);
        const clFail = checkFail(cl, spec.cl);
        const brFail = checkFail(br, spec.br);
        if (!f && !cl && !br) return '-';
        return (
            <div className="text-[10px] font-mono flex flex-col gap-0.5">
                <span className={fFail ? "text-rose-500 font-bold" : "text-slate-600"}>F: {f||0}</span>
                <span className={clFail ? "text-rose-500 font-bold" : "text-slate-600"}>Cl: {cl||0}</span>
                <span className={brFail ? "text-rose-500 font-bold" : "text-slate-600"}>Br: {br||0}</span>
            </div>
        );
    };

    const renderMetal = (lot) => {
        const spec = material.specification?.metal || {};
        const metals = material.specification?.metalElements || STANDARD_METALS;
        let isFail = false;
        metals.forEach((el) => {
            const val = lot.metalResults?.[el];
            const limit = spec[el];
            if (limit && limit !== '' && (parseFloat(val) || 0) > parseFloat(limit)) { isFail = true; }
        });
        if (isFail) return <span className="text-[10px] font-bold text-rose-500 bg-rose-50 px-2 py-1 rounded">Fail</span>;
        return <span className="text-[10px] font-bold text-emerald-500 bg-emerald-50 px-2 py-1 rounded">Pass</span>;
    };

    return (
        // [수정 1] h-full overflow-y-auto 추가하여 탭 자체 스크롤 활성화
        <div className="h-full overflow-y-auto custom-scrollbar bg-slate-50 p-6 space-y-6">
            
            {/* 1. Lot Comparison History Table */}
            <Card title="Lot Comparison History" icon="layers">
                <div className="overflow-x-auto border border-slate-200 rounded-lg bg-white custom-scrollbar">
                    <table className="w-full text-sm text-left whitespace-nowrap">
                         <thead className="bg-slate-100 text-slate-600 uppercase text-xs font-semibold">
                            <tr>
                                <th className="p-3 sticky left-0 z-20 bg-slate-100 border-r border-slate-200 shadow-sm">Lot No.</th>
                                <th className="p-3 w-32">Period</th>
                                <th className="p-3">Syn Site</th>
                                <th className="p-3">Sub Site</th>
                                <th className="p-3">Syn %</th>
                                <th className="p-3">Sub %</th>
                                <th className="p-3 text-purple-600">HPLC Syn</th>
                                <th className="p-3 text-purple-600">HPLC Sub</th>
                                <th className="p-3 text-amber-600">D-Rate</th>
                                <th className="p-3">Mix Ratio</th>
                                <th className="p-3 text-blue-600">Output</th>
                                <th className="p-3">Cost</th>
                                <th className="p-3 text-slate-600">Halogen</th>
                                <th className="p-3 text-slate-600">Metal</th>
                                <th className="p-3 text-emerald-600">Eff</th>
                                <th className="p-3 text-blue-600">Life</th>
                            </tr>
                        </thead>
                        <tbody className="divide-y divide-slate-100 bg-white">
                            {material.lots.map(lot => (
                                <tr key={lot.id} className="hover:bg-slate-50 transition">
                                    <td className="p-3 font-bold text-slate-800 sticky left-0 bg-white z-10 border-r border-slate-100 shadow-sm">{lot.name}</td>
                                    
                                    {/* [수정 2] 날짜 입력 필드 복원 (Input Type Date) */}
                                    <td className="p-3">
                                        <div className="flex flex-col gap-1">
                                            <input 
                                                type="date" 
                                                disabled={readOnly}
                                                className="bg-transparent border-b border-transparent hover:border-slate-300 text-[10px] text-slate-500 outline-none focus:border-brand-500 transition w-full"
                                                value={lot.synDateStart} 
                                                onChange={e=>updateLot(lot.id, 'synDateStart', e.target.value)}
                                            />
                                            <input 
                                                type="date" 
                                                disabled={readOnly}
                                                className="bg-transparent border-b border-transparent hover:border-slate-300 text-[10px] text-slate-500 outline-none focus:border-brand-500 transition w-full"
                                                value={lot.synDateEnd} 
                                                onChange={e=>updateLot(lot.id, 'synDateEnd', e.target.value)}
                                            />
                                        </div>
                                    </td>

                                    <td className="p-3"><input disabled={readOnly} className="bg-transparent w-20 outline-none text-slate-600 border-b border-transparent hover:border-slate-300 focus:border-brand-500 transition text-xs" value={lot.synSite} onChange={e=>updateLot(lot.id,'synSite',e.target.value)} placeholder="Syn"/></td>
                                    <td className="p-3"><input disabled={readOnly} className="bg-transparent w-20 outline-none text-slate-600 border-b border-transparent hover:border-slate-300 focus:border-brand-500 transition text-xs" value={lot.subSite} onChange={e=>updateLot(lot.id,'subSite',e.target.value)} placeholder="Sub"/></td>
                                    <td className="p-3 font-mono font-bold text-slate-700">{lot.synYield}%</td>
                                    <td className="p-3 font-mono font-bold text-slate-700">{lot.subYield}%</td>
                                    <td className="p-3 font-mono font-bold text-purple-600">{lot.hplcSyn}%</td>
                                    <td className="p-3 font-mono font-bold text-purple-600">{lot.hplcSub}%</td>
                                    <td className="p-3 text-center">{renderDRate(lot)}</td>
                                    <td className="p-3 text-center">{renderMixInfo(lot)}</td>
                                    <td className="p-3 font-mono font-bold text-blue-600">{lot.actualOutput}g</td>
                                    <td className="p-3 font-mono text-slate-500">₩{fmtK(lot.unitCost)}</td>
                                    <td className="p-3">{renderHalogen(lot)}</td>
                                    <td className="p-3 text-center">{renderMetal(lot)}</td>
                                    <td className="p-3 font-bold text-emerald-600">{lot.ivlEff}%</td>
                                    <td className="p-3 font-bold text-blue-600">{lot.lifetime}%</td>
                                </tr>
                            ))}
                        </tbody>
                    </table>
                </div>
            </Card>
            
            {/* 2. Charts Grid */}
            <div className="grid grid-cols-2 md:grid-cols-3 gap-4">
                 <div className="h-48"><SimpleLineChart data={material.lots} dataKey="synYield" color="#3b82f6" label="Syn Yield (%)" formatVal={v=>`${v}%`}/></div>
                 <div className="h-48"><SimpleLineChart data={material.lots} dataKey="subYield" color="#f59e0b" label="Sub Yield (%)" formatVal={v=>`${v}%`}/></div>
                 <div className="h-48"><SimpleLineChart data={material.lots} dataKey="hplcSyn" color="#a855f7" label="Syn Purity (%)" formatVal={v=>`${v}%`}/></div>
                 <div className="h-48"><SimpleLineChart data={material.lots} dataKey="hplcSub" color="#ec4899" label="Sub Purity (%)" formatVal={v=>`${v}%`}/></div>
                 <div className="h-48"><SimpleLineChart data={material.lots} dataKey="unitCost" color="#10b981" label="Unit Cost" formatVal={v=>`₩${fmtK(v)}`}/></div>
                 <div className="h-48"><SimpleLineChart data={material.lots} dataKey="lifetime" color="#0ea5e9" label="Device Life (%)" formatVal={v=>`${v}%`}/></div>
            </div>
            
            {/* 3. Impurity Comparison (by RRT) */}
            <Card title="Impurity Comparison (by RRT)" icon="git-branch">
                 <div className="flex justify-end mb-2 relative">
                    <div className="flex items-center gap-2 bg-slate-100 px-3 py-1 rounded-lg border border-slate-200 cursor-pointer hover:bg-slate-200 transition select-none" onClick={() => setIsRefSelectorOpen(!isRefSelectorOpen)}>
                        <span className="text-xs text-slate-500 font-bold">Ref Lots:</span>
                        <span className="text-xs text-brand-600 font-bold">{refLotIds.length} Selected</span>
                        <Icon name="chevron-down" size={12}/>
                    </div>
                    {isRefSelectorOpen && (
                        <div className="absolute top-full right-0 mt-2 w-56 bg-white border border-slate-200 rounded-xl shadow-xl z-50 p-2 animate-in flex flex-col gap-1">
                            <div className="text-[10px] font-bold text-slate-400 px-2 pb-1 border-b border-slate-100 mb-1">Select References</div>
                            {material.lots.map(l => (
                                <div key={l.id} onClick={(e) => { e.stopPropagation(); toggleRef(l.id); }} className={`flex items-center gap-2 p-2 rounded-lg cursor-pointer transition ${refLotIds.includes(l.id) ? 'bg-brand-50' : 'hover:bg-slate-50'}`}>
                                    <div className={`w-4 h-4 rounded border flex items-center justify-center ${refLotIds.includes(l.id) ? 'bg-brand-600 border-brand-600' : 'border-slate-300 bg-white'}`}>
                                        {refLotIds.includes(l.id) && <Icon name="check" size={10} className="text-white"/>}
                                    </div>
                                    <span className={`text-xs font-medium truncate ${refLotIds.includes(l.id) ? 'text-brand-700' : 'text-slate-600'}`}>{l.name}</span>
                                </div>
                            ))}
                            <div className="pt-2 border-t border-slate-100 mt-1">
                                <button onClick={(e)=>{e.stopPropagation(); setIsRefSelectorOpen(false)}} className="w-full text-center text-xs font-bold text-slate-500 hover:text-slate-800 py-1">Close</button>
                            </div>
                        </div>
                    )}
                    {isRefSelectorOpen && <div className="fixed inset-0 z-40" onClick={() => setIsRefSelectorOpen(false)}></div>}
                </div>

                <div className="overflow-x-auto border border-slate-200 rounded-lg custom-scrollbar">
                    <table className="w-full text-xs text-right border-collapse whitespace-nowrap">
                        <thead>
                            <tr className="bg-slate-100 text-slate-500 border-b border-slate-200">
                                <th className="p-3 text-left font-bold w-24 sticky left-0 bg-slate-100 z-10 border-r border-slate-200 shadow-sm">RRT</th>
                                {material.lots.map(lot => {
                                    const isRef = refLotIds.includes(lot.id);
                                    return (
                                        <th key={lot.id} className={`p-3 font-medium min-w-[100px] border-l border-slate-200 ${isRef ? 'text-brand-600 bg-brand-50' : ''}`}>
                                            <div className="flex flex-col items-end">
                                                <span>{lot.name}</span>
                                                {isRef && <span className="text-[9px] bg-brand-200 text-brand-700 px-1.5 rounded-full mt-0.5">Ref</span>}
                                            </div>
                                        </th>
                                    );
                                })}
                            </tr>
                        </thead>
                        <tbody>
                            {impurityComparisonData.length > 0 ? impurityComparisonData.map((peak, idx) => {
                                const refVals = refLotIds.map(id => peak.contents[id] || 0);
                                const maxRefVal = refVals.length > 0 ? Math.max(...refVals) : 0;
                                const isMainPeak = peak.rrt >= 0.95 && peak.rrt <= 1.05;
                                return (
                                    <tr key={idx} className="hover:bg-slate-50 border-b border-slate-100 group">
                                        <td className="p-3 text-left font-mono text-brand-600 font-bold sticky left-0 bg-slate-50 border-r border-slate-200 shadow-sm group-hover:bg-slate-100">{peak.rrt.toFixed(2)}</td>
                                        {material.lots.map(lot => {
                                            const val = peak.contents[lot.id];
                                            const currentVal = val !== undefined ? val : 0;
                                            const isRef = refLotIds.includes(lot.id);
                                            const isWorse = !isMainPeak && !isRef && currentVal > maxRefVal && refLotIds.length > 0;
                                            
                                            let cellClass = "text-slate-500";
                                            if (isRef) cellClass = "text-brand-700 font-bold bg-brand-50/50";
                                            else if (isWorse) cellClass = "text-rose-600 font-bold bg-rose-50/50";
                                            
                                            return <td key={lot.id} className={`p-3 border-l border-slate-100 transition-colors ${cellClass}`}>{val !== undefined ? `${val}%` : '-'}</td>
                                        })}
                                    </tr>
                                );
                            }) : <tr><td colSpan={material.lots.length + 1} className="p-4 text-center text-slate-400 italic">No impurity peaks data available. Check Analysis Tab.</td></tr>}
                        </tbody>
                    </table>
                </div>
            </Card>
        </div>
    );
};