import React, { useState, useEffect } from 'react';
import { Card } from '../../../components/ui/Card';
import { Icon } from '../../../components/ui/Icon';
import { ExcelGrid } from '../../../components/ui/ExcelGrid';
import { ImageUploader } from '../../../components/ui/ImageUploader';
import { FileUploader } from '../../../components/ui/FileUploader';
import { SizeSlider } from '../../../components/ui/SizeSlider';
import { generateId } from '../../../utils/math';
import { sanitizeLot } from '../../../utils/sanitize';

export const AnalysisLotTab = ({ material, updateMaterial, readOnly }) => {
    const [activeLotId, setActiveLotId] = useState(material.lots[0]?.id || null);
    const [viewMode, setViewMode] = useState('chemical');
    const [tgaSize, setTgaSize] = useState(160);
    const [dscSize, setDscSize] = useState(160);
    const [deviceImgSize, setDeviceImgSize] = useState(150);

    useEffect(() => { if (!activeLotId && material.lots.length > 0) setActiveLotId(material.lots[0].id); }, [material.lots, activeLotId]);
    
    const activeLot = material.lots.find(l => l.id === activeLotId);
    const updateLot = (key, val) => { if(!readOnly) updateMaterial({ ...material, lots: material.lots.map(l => l.id === activeLotId ? { ...l, [key]: val } : l) }); };
    const metalElements = material.specification.metalElements || [];

    const addLot = () => { 
        if(!readOnly) { 
            const baseData = { name: `LOT-${new Date().toISOString().slice(2,10).replace(/-/g,'')}-${material.lots.length + 1}` };
            const newLot = sanitizeLot(baseData); 
            // 새 Lot 생성 시 Header 동기화
            const currentPeaks = material.impurityData.peaks;
            const header = ['Parameter', ...currentPeaks.map((_, i) => `Peak ${i+1}`)];
            newLot.hplcGrid = [ header, ['RT', ...Array(currentPeaks.length).fill('')], ['RRT', ...Array(currentPeaks.length).fill('')], ['Content (%)', ...Array(currentPeaks.length).fill('')] ];
            updateMaterial({ ...material, lots: [...material.lots, newLot] }); 
            setActiveLotId(newLot.id); 
        }
    };

    return (
        <div className="flex h-full bg-slate-50">
            <div className="w-64 border-r border-slate-200 bg-white flex flex-col">
                <div className="p-4 border-b border-slate-200 flex justify-between items-center"><span className="font-bold text-xs text-slate-500">SELECT LOT</span>{!readOnly && <button onClick={addLot} className="text-brand-600 hover:bg-brand-50 rounded p-1"><Icon name="plus" size={14}/></button>}</div>
                <div className="flex-1 overflow-y-auto p-2 space-y-1">
                    {material.lots.map(l => (<div key={l.id} onClick={() => setActiveLotId(l.id)} className={`p-3 rounded-lg text-sm cursor-pointer flex justify-between ${activeLotId === l.id ? 'bg-blue-50 text-blue-700 font-bold border border-blue-200' : 'text-slate-600 hover:bg-slate-100'}`}>{l.name}</div>))}
                </div>
            </div>
            <div className="flex-1 overflow-y-auto p-8 space-y-6 custom-scrollbar">
                {activeLot ? (
                    <>
                        <div className="flex justify-between items-end pb-4 border-b border-slate-200">
                            <div><label className="text-xs text-slate-400 block mb-1 font-bold">LOT ID</label><input disabled={readOnly} className="bg-transparent text-3xl font-black text-slate-800 outline-none w-full" value={activeLot.name} onChange={e => updateLot('name', e.target.value)} /></div>
                            <div className="flex gap-2 bg-slate-200 p-1 rounded-lg">
                                <button onClick={()=>setViewMode('chemical')} className={`px-4 py-2 rounded text-sm font-bold transition ${viewMode==='chemical'?'bg-white text-slate-800 shadow-sm':'text-slate-500 hover:text-slate-700'}`}>Chemical</button>
                                <button onClick={()=>setViewMode('device')} className={`px-4 py-2 rounded text-sm font-bold transition ${viewMode==='device'?'bg-white text-slate-800 shadow-sm':'text-slate-500 hover:text-slate-700'}`}>Device</button>
                            </div>
                        </div>
                        {viewMode === 'chemical' ? (
                            <div className="grid grid-cols-12 gap-6 animate-in">
                                <div className="col-span-12 glass-panel p-6 rounded-xl bg-white">
                                    <div className="flex justify-between items-center mb-4">
                                        <h4 className="text-slate-700 font-bold flex items-center gap-2"><Icon name="activity" size={18}/> HPLC Purity Analysis</h4>
                                        <div className="flex items-center gap-4">
                                            <label className="flex items-center gap-2 cursor-pointer bg-slate-50 px-3 py-1.5 rounded-lg border border-slate-200 hover:bg-slate-100 transition">
                                                <input type="checkbox" className="w-4 h-4 accent-brand-600 rounded cursor-pointer" checked={activeLot.isMix} onChange={e=>updateLot('isMix', e.target.checked)} disabled={readOnly}/>
                                                <span className="text-xs font-bold text-slate-600">Mix Product</span>
                                            </label>
                                            <div className="flex items-center gap-2 bg-slate-50 px-3 py-1.5 rounded-lg border border-slate-200"><span className="text-xs text-slate-500 font-bold">Method Ver.</span><select disabled={readOnly} className="bg-transparent text-xs font-mono text-brand-600 font-bold outline-none cursor-pointer" value={activeLot.hplcMethodVersion} onChange={e=>updateLot('hplcMethodVersion', e.target.value)}><option value="">None</option>{material.methods && material.methods.map(m => (<option key={m.id} value={m.version}>{m.version}</option>))}</select></div>
                                        </div>
                                    </div>

                                    {/* HPLC INPUT SECTION (RESTORED FROM HTML) */}
                                    {activeLot.isMix ? (
                                        <div className="space-y-4 mb-6">
                                            <div className="flex justify-end mb-2"><div className="bg-slate-100 p-1 rounded-lg flex text-xs font-bold"><button onClick={()=>updateLot('mixCount', 2)} className={`px-3 py-1 rounded ${activeLot.mixCount !== 3 ? 'bg-white text-slate-800 shadow-sm' : 'text-slate-400'}`}>2-Comp</button><button onClick={()=>updateLot('mixCount', 3)} className={`px-3 py-1 rounded ${activeLot.mixCount === 3 ? 'bg-white text-slate-800 shadow-sm' : 'text-slate-400'}`}>3-Comp</button></div></div>
                                            <div className="flex gap-4 items-center bg-slate-50 p-3 rounded-xl border border-slate-200 overflow-x-auto">
                                                <span className="text-sm font-bold text-slate-600 w-24 flex-shrink-0"><Icon name="git-merge" size={14} className="inline mr-1"/> Mix Ratio</span>
                                                <div className="flex items-center gap-2"><input disabled={readOnly} className="w-8 text-xs font-bold text-center bg-blue-100 text-blue-600 rounded border-none outline-none" value={activeLot.comp1Label} onChange={e=>updateLot('comp1Label', e.target.value)}/><input disabled={readOnly} type="number" className="bg-white border border-slate-300 rounded px-2 py-1 w-16 text-right text-sm font-bold outline-none focus:border-brand-500" value={activeLot.pRatio} onChange={e=>updateLot('pRatio', e.target.value)} placeholder="0"/></div>
                                                <span className="text-slate-400 font-bold">:</span>
                                                <div className="flex items-center gap-2"><input disabled={readOnly} className="w-8 text-xs font-bold text-center bg-rose-100 text-rose-600 rounded border-none outline-none" value={activeLot.comp2Label} onChange={e=>updateLot('comp2Label', e.target.value)}/><input disabled={readOnly} type="number" className="bg-white border border-slate-300 rounded px-2 py-1 w-16 text-right text-sm font-bold outline-none focus:border-brand-500" value={activeLot.nRatio} onChange={e=>updateLot('nRatio', e.target.value)} placeholder="0"/></div>
                                                {activeLot.mixCount === 3 && (<><span className="text-slate-400 font-bold">:</span><div className="flex items-center gap-2"><input disabled={readOnly} className="w-8 text-xs font-bold text-center bg-emerald-100 text-emerald-600 rounded border-none outline-none" value={activeLot.comp3Label} onChange={e=>updateLot('comp3Label', e.target.value)}/><input disabled={readOnly} type="number" className="bg-white border border-slate-300 rounded px-2 py-1 w-16 text-right text-sm font-bold outline-none focus:border-brand-500" value={activeLot.mixRatio3} onChange={e=>updateLot('mixRatio3', e.target.value)} placeholder="0"/></div></>)}
                                            </div>
                                            <div className={`grid gap-4 ${activeLot.mixCount === 3 ? 'grid-cols-3' : 'grid-cols-2'}`}>
                                                <div className="bg-blue-50/50 p-3 rounded-xl border border-blue-100">
                                                    <div className="text-xs font-bold text-blue-600 text-center bg-blue-100 rounded py-1 mb-2">{activeLot.comp1Label}</div>
                                                    <div className="space-y-2">
                                                        <div><label className="text-[10px] text-slate-400 block mb-0.5">Syn Purity</label><div className="flex items-baseline"><input disabled={readOnly} className="w-full bg-transparent text-lg font-black text-slate-800 outline-none" value={activeLot.hplcSynP} onChange={e=>updateLot('hplcSynP', e.target.value)} placeholder="0.00"/><span className="text-xs text-slate-400">%</span></div></div>
                                                        <div className="border-t border-blue-100 pt-1"><label className="text-[10px] text-slate-400 block mb-0.5">Sub Purity</label><div className="flex items-baseline"><input disabled={readOnly} className="w-full bg-transparent text-lg font-black text-brand-600 outline-none" value={activeLot.hplcSubP} onChange={e=>updateLot('hplcSubP', e.target.value)} placeholder="0.00"/><span className="text-xs text-slate-400">%</span></div></div>
                                                        <div className="border-t border-blue-100 pt-1"><label className="text-[10px] text-slate-400 block mb-0.5">D-Rate</label><div className="flex items-baseline"><input disabled={readOnly} className="w-full bg-transparent text-lg font-black text-slate-600 outline-none" value={activeLot.dRateP} onChange={e=>updateLot('dRateP', e.target.value)} placeholder="0"/><span className="text-xs text-slate-400">%</span></div></div>
                                                    </div>
                                                </div>
                                                <div className="bg-rose-50/50 p-3 rounded-xl border border-rose-100">
                                                    <div className="text-xs font-bold text-rose-600 text-center bg-rose-100 rounded py-1 mb-2">{activeLot.comp2Label}</div>
                                                    <div className="space-y-2">
                                                        <div><label className="text-[10px] text-slate-400 block mb-0.5">Syn Purity</label><div className="flex items-baseline"><input disabled={readOnly} className="w-full bg-transparent text-lg font-black text-slate-800 outline-none" value={activeLot.hplcSynN} onChange={e=>updateLot('hplcSynN', e.target.value)} placeholder="0.00"/><span className="text-xs text-slate-400">%</span></div></div>
                                                        <div className="border-t border-rose-100 pt-1"><label className="text-[10px] text-slate-400 block mb-0.5">Sub Purity</label><div className="flex items-baseline"><input disabled={readOnly} className="w-full bg-transparent text-lg font-black text-brand-600 outline-none" value={activeLot.hplcSubN} onChange={e=>updateLot('hplcSubN', e.target.value)} placeholder="0.00"/><span className="text-xs text-slate-400">%</span></div></div>
                                                        <div className="border-t border-rose-100 pt-1"><label className="text-[10px] text-slate-400 block mb-0.5">D-Rate</label><div className="flex items-baseline"><input disabled={readOnly} className="w-full bg-transparent text-lg font-black text-slate-600 outline-none" value={activeLot.dRateN} onChange={e=>updateLot('dRateN', e.target.value)} placeholder="0"/><span className="text-xs text-slate-400">%</span></div></div>
                                                    </div>
                                                </div>
                                                {activeLot.mixCount === 3 && (
                                                    <div className="bg-emerald-50/50 p-3 rounded-xl border border-emerald-100">
                                                        <div className="text-xs font-bold text-emerald-600 text-center bg-emerald-100 rounded py-1 mb-2">{activeLot.comp3Label}</div>
                                                        <div className="space-y-2">
                                                            <div><label className="text-[10px] text-slate-400 block mb-0.5">Syn Purity</label><div className="flex items-baseline"><input disabled={readOnly} className="w-full bg-transparent text-lg font-black text-slate-800 outline-none" value={activeLot.hplcSyn3} onChange={e=>updateLot('hplcSyn3', e.target.value)} placeholder="0.00"/><span className="text-xs text-slate-400">%</span></div></div>
                                                            <div className="border-t border-emerald-100 pt-1"><label className="text-[10px] text-slate-400 block mb-0.5">Sub Purity</label><div className="flex items-baseline"><input disabled={readOnly} className="w-full bg-transparent text-lg font-black text-brand-600 outline-none" value={activeLot.hplcSub3} onChange={e=>updateLot('hplcSub3', e.target.value)} placeholder="0.00"/><span className="text-xs text-slate-400">%</span></div></div>
                                                            <div className="border-t border-emerald-100 pt-1"><label className="text-[10px] text-slate-400 block mb-0.5">D-Rate</label><div className="flex items-baseline"><input disabled={readOnly} className="w-full bg-transparent text-lg font-black text-slate-600 outline-none" value={activeLot.dRate3} onChange={e=>updateLot('dRate3', e.target.value)} placeholder="0"/><span className="text-xs text-slate-400">%</span></div></div>
                                                        </div>
                                                    </div>
                                                )}
                                            </div>
                                        </div>
                                    ) : (
                                        <div className="grid grid-cols-4 gap-6 mb-6">
                                            <div className="bg-slate-50 p-4 rounded-xl border border-slate-200 flex justify-between items-center"><span className="text-sm font-bold text-slate-500">Synthesis</span><div className="flex items-baseline"><input disabled={readOnly} className="bg-transparent text-2xl font-black text-slate-800 outline-none w-24 text-right" value={activeLot.hplcSyn} onChange={e=>updateLot('hplcSyn', e.target.value)} placeholder="0.0"/><span className="text-sm font-medium text-slate-400 ml-1">%</span></div></div>
                                            <div className="bg-slate-50 p-4 rounded-xl border border-slate-200 flex justify-between items-center"><span className="text-sm font-bold text-slate-500">Sublimation</span><div className="flex items-baseline"><input disabled={readOnly} className="bg-transparent text-2xl font-black text-brand-600 outline-none w-24 text-right" value={activeLot.hplcSub} onChange={e=>updateLot('hplcSub', e.target.value)} placeholder="0.0"/><span className="text-sm font-medium text-slate-400 ml-1">%</span></div></div>
                                            <div className="bg-amber-50 p-4 rounded-xl border border-amber-200 flex justify-between items-center"><span className="text-sm font-bold text-amber-600">D-Rate</span><div className="flex items-baseline"><input disabled={readOnly} className="bg-transparent text-2xl font-black text-amber-600 outline-none w-24 text-right" value={activeLot.dRate} onChange={e=>updateLot('dRate', e.target.value)} placeholder="0"/><span className="text-sm font-medium text-slate-400 ml-1">%</span></div></div>
                                            <div className="flex flex-col gap-2">
                                                <FileUploader files={activeLot.hplcSynFiles} setFiles={f => updateLot('hplcSynFiles', f)} label="Syn HPLC Reports" readOnly={readOnly} />
                                            </div>
                                        </div>
                                    )}

                                    <div className="mb-6"><label className="text-xs font-bold text-slate-500 uppercase mb-2 block">Synthesis History</label><textarea disabled={readOnly} className="w-full bg-slate-50 border border-slate-200 rounded-lg p-3 text-sm text-slate-700 outline-none" rows="3" value={activeLot.synHistory || ''} onChange={e=>updateLot('synHistory', e.target.value)}></textarea></div>
                                    <ExcelGrid data={activeLot.hplcGrid || []} setData={d => updateLot('hplcGrid', d)} title="Impurity Peaks Table" className="h-64" readOnly={readOnly} />
                                </div>
                                
                                {/* TGA, DSC, Metal Analysis */}
                                <div className="col-span-12 glass-panel p-6 rounded-xl bg-white">
                                    <h4 className="text-slate-700 font-bold mb-4 flex items-center gap-2"><Icon name="alert-triangle" size={18}/> Impurity Analysis (Metal & Halogen)</h4>
                                    <div className="mb-6"><label className="text-xs font-bold text-slate-500 uppercase mb-2 block">Halogen (ppm)</label><div className="flex gap-4">{['f','cl','br'].map(el => (<div key={el} className="flex items-center bg-slate-50 border border-slate-200 rounded-lg px-3 py-2"><span className="text-xs font-bold text-slate-500 uppercase mr-2">{el}</span><input disabled={readOnly} className="bg-transparent text-slate-800 font-bold outline-none w-16 text-right" placeholder="0" value={activeLot.halogen[el]} onChange={e=>updateLot('halogen', {...activeLot.halogen, [el]:e.target.value})} /></div>))}</div></div>
                                    <div><label className="text-xs font-bold text-slate-500 uppercase mb-2 block">Metal (ppm)</label><div className="flex flex-wrap gap-2">{metalElements.map((el) => (<div key={el} className="bg-slate-50 border border-slate-200 rounded p-2 text-center min-w-[60px]"><span className="text-[10px] text-slate-400 block font-bold mb-1">{el}</span><input disabled={readOnly} className="w-full bg-transparent text-center font-bold text-slate-800 outline-none text-sm" value={activeLot.metalResults?.[el] || ''} onChange={e=>{const newResults = {...(activeLot.metalResults || {})}; newResults[el] = e.target.value; updateLot('metalResults', newResults);}} placeholder="-"/></div>))}</div></div>
                                </div>

                                <div className="col-span-12 grid grid-cols-2 gap-6">
                                    <Card title="TGA Analysis" icon="flame" color="text-amber-600" action={<SizeSlider value={tgaSize} onChange={setTgaSize} />}>
                                        <div className="flex gap-4 mb-3 p-2 bg-amber-50/50 rounded-lg border border-amber-100"><div className="flex-1"><label className="text-[10px] font-bold text-amber-600 block mb-1">Td 1% (°C)</label><input disabled={readOnly} className="w-full bg-white border border-amber-200 rounded px-2 py-1 text-sm font-bold text-slate-700 outline-none focus:border-amber-500" value={activeLot.td1} onChange={e=>updateLot('td1', e.target.value)} placeholder="-"/></div><div className="flex-1"><label className="text-[10px] font-bold text-amber-600 block mb-1">Td 5% (°C)</label><input disabled={readOnly} className="w-full bg-white border border-amber-200 rounded px-2 py-1 text-sm font-bold text-slate-700 outline-none focus:border-amber-500" value={activeLot.td5} onChange={e=>updateLot('td5', e.target.value)} placeholder="-"/></div></div>
                                        <div className="grid grid-cols-2 gap-2" style={{ height: `${tgaSize}px` }}>{activeLot.tgaImages?.map((img,i)=><ImageUploader key={i} value={img.src} onChange={v=>v?null:updateLot('tgaImages', activeLot.tgaImages.filter((_,x)=>x!==i))} readOnly={readOnly}/>)}<ImageUploader onChange={v=>v&&updateLot('tgaImages',[...(activeLot.tgaImages||[]),{src:v}])} label="Add Graph" readOnly={readOnly}/></div>
                                    </Card>
                                    <Card title="DSC Analysis" icon="thermometer" color="text-amber-600" action={<SizeSlider value={dscSize} onChange={setDscSize} />}>
                                         <div className="grid grid-cols-2 gap-2" style={{ height: `${dscSize}px` }}>{activeLot.dscImages?.map((img,i)=><ImageUploader key={i} value={img.src} onChange={v=>v?null:updateLot('dscImages', activeLot.dscImages.filter((_,x)=>x!==i))} readOnly={readOnly}/>)}<ImageUploader onChange={v=>v&&updateLot('dscImages',[...(activeLot.dscImages||[]),{src:v}])} label="Add Graph" readOnly={readOnly}/></div>
                                    </Card>
                                </div>
                            </div>
                        ) : (
                            <div className="grid grid-cols-12 gap-6 animate-in">
                                <div className="col-span-4 space-y-6">
                                    <Card title="Efficiency" icon="zap" color="text-emerald-600"><input disabled={readOnly} className="text-5xl font-black text-slate-800 text-center w-full outline-none bg-transparent" value={activeLot.ivlEff || ''} onChange={e=>updateLot('ivlEff', e.target.value)} /><span className="text-center block text-slate-400 text-sm">%</span></Card>
                                    <Card title="Lifetime" icon="clock" color="text-blue-600"><input disabled={readOnly} className="text-5xl font-black text-slate-800 text-center w-full outline-none bg-transparent" value={activeLot.lifetime || ''} onChange={e=>updateLot('lifetime', e.target.value)} /><span className="text-center block text-slate-400 text-sm">%</span></Card>
                                </div>
                                <div className="col-span-8 bg-white p-6 rounded-xl border border-slate-200 h-full relative group">
                                    <div className="flex justify-between items-center mb-4"><h4 className="text-slate-700 font-bold flex items-center gap-2"><Icon name="image" size={16}/> Evaluation Data</h4><SizeSlider value={deviceImgSize} onChange={setDeviceImgSize} /></div>
                                    <div className="grid grid-cols-3 gap-4" style={{ gridAutoRows: `${deviceImgSize}px` }}>{activeLot.deviceImages?.map((img,i)=><ImageUploader key={i} value={img.src} onChange={v=>v?null:updateLot('deviceImages', activeLot.deviceImages.filter((_,x)=>x!==i))} readOnly={readOnly}/>)}<ImageUploader onChange={v=>v&&updateLot('deviceImages',[...(activeLot.deviceImages||[]),{src:v}])} label="Add Plot" readOnly={readOnly}/></div>
                                </div>
                            </div>
                        )}
                    </>
                ) : <div className="flex h-full flex-col items-center justify-center text-slate-400 gap-4"><Icon name="flask-conical" size={48} className="opacity-20"/><p>No Analysis Lot selected.</p></div>}
            </div>
        </div>
    );
};