import React, { useState } from 'react';
import { Icon } from '../../components/ui/Icon';
import { VALID_KEYS } from '../../constants';
import { api } from '../../services/api';

export const LicenseScreen = ({ onActivate }) => {
    const [inputKey, setInputKey] = useState('');
    const [error, setError] = useState('');
    const [status, setStatus] = useState('IDLE');

    const handleInputChange = (e) => {
        let val = e.target.value.toUpperCase();
        val = val.replace(/[^A-Z0-9]/g, '');
        val = val.replace(/(.{4})(?=.)/g, '$1-');
        if (val.length <= 19) { setInputKey(val); setError(''); }
    };

    const handleActivate = async (e) => {
        e.preventDefault();
        if (VALID_KEYS.includes(inputKey)) {
            setStatus('SUCCESS');
            const oneYearLater = new Date(); oneYearLater.setFullYear(oneYearLater.getFullYear() + 1);
            const licenseData = { key: inputKey, activatedAt: new Date().toISOString(), expiresAt: oneYearLater.toISOString(), isValid: true };
            await api.license.save(licenseData);
            setTimeout(() => { onActivate(); }, 1500);
        } else { setError('Invalid License Key. Please check your key.'); }
    };

    return (
        <div className="fixed inset-0 z-[100] flex items-center justify-center bg-slate-50">
            <div className="w-full max-w-md p-8 bg-white rounded-2xl border border-slate-200 shadow-2xl relative z-10 animate-in">
                <div className="text-center mb-8">
                    <div className={`inline-flex items-center justify-center w-16 h-16 rounded-full mb-4 border transition-all duration-500 ${status === 'SUCCESS' ? 'bg-emerald-100 border-emerald-200 text-emerald-600' : 'bg-slate-100 border-slate-200 text-slate-500'}`}><Icon name={status === 'SUCCESS' ? 'check' : 'lock'} size={32}/></div>
                    <h1 className="text-2xl font-bold text-slate-800 tracking-tight">License Activation</h1>
                    <p className="text-slate-500 text-sm mt-2">OLED Matflow v1 Professional</p>
                </div>
                {status === 'SUCCESS' ? (
                    <div className="text-center animate-in"><div className="text-emerald-600 font-bold text-lg mb-2">Activation Successful!</div><p className="text-slate-500 text-sm">License valid for 1 year.</p><p className="text-slate-400 text-xs mt-4">Redirecting...</p></div>
                ) : (
                    <form onSubmit={handleActivate} className="space-y-4">
                        <div><label className="block text-xs font-bold text-slate-500 uppercase mb-1">Enter License Key</label><input type="text" className="w-full bg-slate-50 border border-slate-200 rounded-lg px-4 py-3 text-slate-800 outline-none focus:border-brand-500 transition font-mono text-center uppercase tracking-widest placeholder-slate-300 text-lg" placeholder="XXXX-XXXX-XXXX-XXXX" value={inputKey} onChange={handleInputChange} maxLength={19}/></div>
                        {error && <div className="text-rose-500 text-sm text-center bg-rose-50 p-2 rounded border border-rose-100 flex items-center justify-center gap-2"><Icon name="alert-triangle" size={14}/> {error}</div>}
                        <button type="submit" className="w-full bg-slate-800 hover:bg-slate-900 text-white font-bold py-3 rounded-lg transition shadow-md flex items-center justify-center gap-2"><Icon name="check-circle" size={16}/> Activate License</button>
                    </form>
                )}
                <div className="mt-8 pt-6 border-t border-slate-100 text-center text-[10px] text-slate-400">System ID: {navigator.userAgent.replace(/[^0-9]/g, '').slice(0,12)}<br/>Please contact support to renew your license.</div>
            </div>
        </div>
    );
};